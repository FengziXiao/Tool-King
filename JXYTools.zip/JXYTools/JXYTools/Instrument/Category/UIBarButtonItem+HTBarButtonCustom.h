//
//  UIBarButtonItem+HTBarButtonCustom.h
//  JXYTools
//
//  Created by yongjing.xiao on 2017/7/13.
//  Copyright © 2017年 fengzixiao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (HTBarButtonCustom)

+ (UIBarButtonItem *)itemWithTarget:(id)target action:(SEL)action image:(NSString *)image selectImage:(NSString *)selectImage;

+ (UIBarButtonItem *)itemWithTarget:(id)target action:(SEL)action image:(NSString *)image selectImage:(NSString *)selectImage title:(NSString *)title;

@end
