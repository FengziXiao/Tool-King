//
//  AppDelegate+AppService.h
//  JXYTools
//
//  Created by yongjing.xiao on 2017/7/14.
//  Copyright © 2017年 fengzixiao. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (AppService)

//监听网络状态
- (void)monitorNetworkStatus;

@end
