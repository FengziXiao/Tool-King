//
//  ThirdMacros.h
//  JXYTools
//
//  Created by yongjing.xiao on 2017/7/13.
//  Copyright © 2017年 fengzixiao. All rights reserved.
//

#ifndef ThirdMacros_h
#define ThirdMacros_h


// 友盟统计
#define UMengKey @"59281b4a5312dd3f5f0005ed"

//微信
#define kAppKey_Wechat          @"wx38ae805374bd9c73"
#define kSecret_Wechat          @"b319a731d49e8c67eec203731d05dd45"

// 腾讯
#define kAppKey_Tencent          @"1106139910"


//网易云信
#define kIMAppKey @"afc7265de3857bbaa7404b4ea92b191e"
#define kIMAppSecret @"c34bd403b29a"
#define kIMPushCerName @""


//图灵机器人  appkey
#define kTLRobotAppKey @"c49dcaf087734705b78e9afd802a0c3f"

#endif /* ThirdMacros_h */
