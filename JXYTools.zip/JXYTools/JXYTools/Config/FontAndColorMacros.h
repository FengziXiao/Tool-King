//
//  FontAndColorMacros.h
//  JXYTools
//
//  Created by yongjing.xiao on 2017/7/13.
//  Copyright © 2017年 fengzixiao. All rights reserved.
//

#ifndef FontAndColorMacros_h
#define FontAndColorMacros_h

// 设置颜色
#define SetColor(r, g, b) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:1.0f]
#define SetAColor(r, g, b, a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]


//默认页面背景色
#define TKViewBgColor SetColor(56, 55, 60)


// 设置字体
#define TKSetFont(fontName,font)    [UIFont fontWithName:(fontName) size:(font)]

#endif /* FontAndColorMacros_h */
