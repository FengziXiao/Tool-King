//
//  JXYFoldingTabBarControllerConfig.m
//  JXYTools
//
//  Created by yongjing.xiao on 2017/7/13.
//  Copyright © 2017年 fengzixiao. All rights reserved.
//

#import "TKFoldingTabBarControllerConfig.h"

@interface TKFoldingTabBarControllerConfig()

@property (nonatomic, readwrite, strong) YALFoldingTabBarController *flodingTabBarController;

@end

@implementation TKFoldingTabBarControllerConfig

- (YALFoldingTabBarController *)flodingTabBarController
{
    return TK_LAZY(_flodingTabBarController, ({
        
        YALFoldingTabBarController *tabBarVC = [[YALFoldingTabBarController alloc] init];
        tabBarVC.viewControllers = [self viewControllersForController];
        [self customFoldingTabBarAppearance:tabBarVC];
        tabBarVC;
        
    }));
}

- (NSArray *)viewControllersForController {
    
    // 首页
    FirstViewController *firstViewC = [[FirstViewController alloc] init];
    firstViewC.title = @"首页";
    TKNavigationController *firstNavigationC = [[TKNavigationController alloc]
                                                                   initWithRootViewController:firstViewC];
    
    // 发现
    SecondViewController *secondViewC = [[SecondViewController alloc] init];
    secondViewC.title = @"发现";
    TKNavigationController *secondNavigationC = [[TKNavigationController alloc]
                                                                    initWithRootViewController:secondViewC];
    
    // 目的地
    ThirdViewController *thirdViewC = [[ThirdViewController alloc] init];
    thirdViewC.title = @"目的地";
    TKNavigationController *thirdNavigationC = [[TKNavigationController alloc]
                                                                   initWithRootViewController:thirdViewC];
    
    // 我的
    FourthViewController *fourthViewC = [[FourthViewController alloc] init];
    fourthViewC.title = @"我的";
    TKNavigationController *fourNavigationC = [[TKNavigationController alloc]
                                                                  initWithRootViewController:fourthViewC];
    
    NSArray *viewControllers = @[
                                 firstNavigationC,
                                 secondNavigationC,
                                 thirdNavigationC,
                                 fourNavigationC
                                 ];
    return viewControllers;
}

- (void)customFoldingTabBarAppearance:(YALFoldingTabBarController *)tabBarVC
{
    YALTabBarItem *item1 = [[YALTabBarItem alloc] initWithItemImage:[UIImage imageNamed:@"nearby_icon"]
                                                      leftItemImage:nil
                                                     rightItemImage:nil];
    
    
    YALTabBarItem *item2 = [[YALTabBarItem alloc] initWithItemImage:[UIImage imageNamed:@"profile_icon"]
                                                      leftItemImage:nil
                                                     rightItemImage:nil];
    
    tabBarVC.leftBarItems = @[item1, item2];
    
    
    YALTabBarItem *item3 = [[YALTabBarItem alloc] initWithItemImage:[UIImage imageNamed:@"chats_icon"]
                                                      leftItemImage:nil
                                                     rightItemImage:nil];
    
    
    YALTabBarItem *item4 = [[YALTabBarItem alloc] initWithItemImage:[UIImage imageNamed:@"settings_icon"]
                                                      leftItemImage:nil
                                                     rightItemImage:nil];
    
    tabBarVC.rightBarItems = @[item3, item4];
    
    tabBarVC.centerButtonImage = [UIImage imageNamed:@"plus_icon"];
    
    tabBarVC.selectedIndex = 0;
    
    
    tabBarVC.tabBarView.extraTabBarItemHeight = YALExtraTabBarItemsDefaultHeight;
    tabBarVC.tabBarView.offsetForExtraTabBarItems = YALForExtraTabBarItemsDefaultOffset;
    tabBarVC.tabBarView.tabBarColor = TKViewBgColor;
    tabBarVC.tabBarViewHeight = YALTabBarViewDefaultHeight;
    tabBarVC.tabBarView.tabBarViewEdgeInsets = UIEdgeInsetsMake(-15.0f, 15.0f, 10.0f, 15.0f);
    tabBarVC.tabBarView.tabBarItemsEdgeInsets = UIEdgeInsetsMake(5.0f, 5.0f, 5.0f, 5.0f);
}


@end
