//
//  JXYFoldingTabBarControllerConfig.h
//  JXYTools
//
//  Created by yongjing.xiao on 2017/7/13.
//  Copyright © 2017年 fengzixiao. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <YALFoldingTabBarController.h>
#import <YALTabBarItem.h>
#import <YALAnimatingTabBarConstants.h>

@interface TKFoldingTabBarControllerConfig : NSObject

@property (strong, nonatomic,readonly) YALFoldingTabBarController *flodingTabBarController;


@end
