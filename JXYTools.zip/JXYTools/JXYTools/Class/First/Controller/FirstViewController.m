//
//  ViewController.m
//  JXYTools
//
//  Created by yongjing.xiao on 2017/7/10.
//  Copyright © 2017年 fengzixiao. All rights reserved.
//

#import "FirstViewController.h"
#import "HomeListCollectionViewCell.h"
#import "RobotDetailViewController.h"
#import "expressSearchViewController.h"

@interface FirstViewController ()<UICollectionViewDataSource,UICollectionViewDelegate>

@property (nonatomic ,strong)UICollectionView *mainCollectionView;
@property (nonatomic ,copy)NSArray *titleArray;

@end

static NSString * const HomeCellID = @"HomeCellID";

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置UI
    [self setupUI];
    
    //读取plist
    [self getDataFromPlist];

}


- (void)getDataFromPlist{
    NSString *plistPath = [[NSBundle mainBundle]pathForResource:@"HomeTitle" ofType:@"plist"];
    NSDictionary *dataDic = [[NSDictionary alloc]initWithContentsOfFile:plistPath];
    _titleArray = [dataDic objectForKey:@"titleArray"];
    [_mainCollectionView reloadData];//刷新
}


-(void)getAllFontName{
    NSArray *familyFonts = [UIFont familyNames];
    for (NSString * fontStr in familyFonts) {
        NSArray *fonts = [UIFont fontNamesForFamilyName:fontStr];
        for (NSString *fontStr in fonts) {
            NSLog(@"fontStr =  %@" , fontStr);
        }
    }
}


#pragma mark =======================设置子控件=======================
-(void)setupUI{
    //间距
    CGFloat padding = 20;
    //卡片的宽高
    CGFloat cardWidth = (KScreenWidth - padding)/2;
    // 创建布局
    UICollectionViewFlowLayout * layout = [[UICollectionViewFlowLayout alloc]init];
    layout.itemSize = CGSizeMake(cardWidth, cardWidth);
    layout.minimumLineSpacing = padding;//行之间的间隔
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    
    
    _mainCollectionView = [[UICollectionView alloc]initWithFrame:self.view.bounds collectionViewLayout:layout];
    _mainCollectionView.backgroundColor = KWhiteColor;
    _mainCollectionView.showsVerticalScrollIndicator = NO;
    _mainCollectionView.delegate = self;
    _mainCollectionView.dataSource = self;
    
    self.view = _mainCollectionView;
    
    // 注册
    [_mainCollectionView registerNib:[UINib nibWithNibName:@"HomeListCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:HomeCellID];
}

#pragma mark - <UICollectionViewDataSource>
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return _titleArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    HomeListCollectionViewCell * cell = (HomeListCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:HomeCellID forIndexPath:indexPath];
    //前缀
    NSString *prefix = @"";
    if (indexPath.row < 9) {
        prefix = @"nlsc_icon00";
    }else{
        prefix = @"nlsc_icon0";
    }
    NSString *imageName = [NSString stringWithFormat:@"%@%ld",prefix,indexPath.row + 1];
    NSString *title = @"";
    if (_titleArray.count > 0) {
        title = _titleArray[indexPath.row];
    }
    [cell setCellWithText:title image:imageName];
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.row) {
        case 0:
        {
            expressSearchViewController *expressVC = [[expressSearchViewController alloc]init];
            [self.navigationController pushViewController:expressVC animated:YES];
        }
            break;
        default:
        {
            RobotDetailViewController *robotVC = [[RobotDetailViewController alloc]init];
            robotVC.topic = @"讲个笑话";
            [self.navigationController pushViewController:robotVC animated:YES];
        }
            break;
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
