//
//  RobotDetailViewController.m
//  JXYTools
//
//  Created by yongjing.xiao on 2017/7/14.
//  Copyright © 2017年 fengzixiao. All rights reserved.
//

#import "RobotDetailViewController.h"

@interface RobotDetailViewController ()

@property (nonatomic ,strong)UITextView *mainTextView;

@end

@implementation RobotDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = KWhiteColor;
    self.navigationItem.title = _topic;
    [self setupUI];
    [self getData];
}

#pragma mark =======================设置界面=======================
-(void)setupUI{
    //返回按钮
    UIButton *backBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, KScreenHeight - 40, KScreenWidth/2, 40)];
    backBtn.backgroundColor = SetColor(80, 189, 203);
    [backBtn setTitle:@"返回吧" forState:UIWindowLevelNormal];
    [backBtn addTarget:self action:@selector(popBack) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backBtn];
    //刷新按钮
    UIButton *refreshBtn = [[UIButton alloc]initWithFrame:CGRectMake(KScreenWidth/2, KScreenHeight - 40, KScreenWidth/2, 40)];
    refreshBtn.backgroundColor = SetColor(235,120,100);
    [refreshBtn setTitle:@"换一个" forState:UIWindowLevelNormal];
    [refreshBtn addTarget:self action:@selector(getData) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:refreshBtn];
    //显示数据
    _mainTextView = [[UITextView alloc]initWithFrame:CGRectMake(0, 64, KScreenWidth, KScreenHeight - 40 - 64)];
    _mainTextView.editable = NO;
    _mainTextView.text = @"正在获取最新数据，请稍等";
    [self.view addSubview:_mainTextView];
}
#pragma mark =======================获取数据=======================
-(void)getData{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [PPNetworkHelper POST:Main_Url parameters:@{@"key":kTLRobotAppKey,@"info":_topic} success:^(id responseObject) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([responseObject objectForKey:@"text"]) {
            NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
            paragraphStyle.lineSpacing = 10;// 字体的行间距
            NSDictionary *attributes = @{
                                         NSFontAttributeName:TKSetFont(@"KohinoorTelugu-Medium", 17),
                                         NSParagraphStyleAttributeName:paragraphStyle
                                         };
            _mainTextView.attributedText = [[NSAttributedString alloc] initWithString:[responseObject objectForKey:@"text"] attributes:attributes];
        }
    } failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

#pragma mark =======================返回操作=======================
-(void)popBack{
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
