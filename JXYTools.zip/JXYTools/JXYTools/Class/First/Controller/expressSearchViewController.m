//
//  expressSearchViewController.m
//  JXYTools
//
//  Created by yongjing.xiao on 2017/7/14.
//  Copyright © 2017年 fengzixiao. All rights reserved.
//

#import "expressSearchViewController.h"

@interface expressSearchViewController ()


/**
 快递单号
 */
@property (weak, nonatomic) IBOutlet UITextField *expressField;

/**
 详细信息
 */
@property (weak, nonatomic) IBOutlet UITextView *detailText;



@end

@implementation expressSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = KWhiteColor;
    self.title = @"快递查询";
}


#pragma mark =======================返回操作=======================
- (IBAction)popBack:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark =======================刷新数据=======================
- (IBAction)refreshData:(UIButton *)sender {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSString *info = [NSString stringWithFormat:@"查询快递%@",_expressField.text];
    [PPNetworkHelper POST:Main_Url parameters:@{@"key":kTLRobotAppKey,@"info":info,@"userid":@"123456"} success:^(id responseObject) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([responseObject objectForKey:@"text"]) {
            NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
            paragraphStyle.lineSpacing = 10;// 字体的行间距
            NSDictionary *attributes = @{
                                         NSFontAttributeName:[UIFont systemFontOfSize:14],
                                         NSParagraphStyleAttributeName:paragraphStyle
                                         };
            _detailText.attributedText = [[NSAttributedString alloc] initWithString:[responseObject objectForKey:@"text"] attributes:attributes];
        }
    } failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
