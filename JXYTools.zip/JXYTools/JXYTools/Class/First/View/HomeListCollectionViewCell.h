//
//  HomeListCollectionViewCell.h
//  JXYTools
//
//  Created by yongjing.xiao on 2017/7/14.
//  Copyright © 2017年 fengzixiao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeListCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *bgImageView;

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

-(void)setCellWithText:(NSString *)text image:(NSString *)imageName;


@end
