//
//  HomeListCollectionViewCell.m
//  JXYTools
//
//  Created by yongjing.xiao on 2017/7/14.
//  Copyright © 2017年 fengzixiao. All rights reserved.
//

#import "HomeListCollectionViewCell.h"

@implementation HomeListCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setCellWithText:(NSString *)text image:(NSString *)imageName{
    self.titleLabel.text = text;
    self.bgImageView.image = [UIImage imageNamed:imageName];
}

@end
