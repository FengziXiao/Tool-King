//
//  main.m
//  JXYTools
//
//  Created by yongjing.xiao on 2017/7/10.
//  Copyright © 2017年 fengzixiao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
